import React from 'react';

const About = () => {
  return (
    <div>
      <h2>About Student Management System</h2>
      <p>This system is designed to manage student records, including registration and login functionality.</p>
    </div>
  );
};

export default About;
